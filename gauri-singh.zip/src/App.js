import React from "react";
import CustomSelect from "./Component/CustomSelect";

function App() {
  return (
    <div className="App">
      <CustomSelect />
    </div>
  );
}

export default App;
